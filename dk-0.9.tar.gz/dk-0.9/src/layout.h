/* dk - /dəˈkā/ window manager
 *
 * see license file for copyright and license details
 * vim:ft=c:fdm=syntax:ts=4:sts=4:sw=4
 */

#pragma once

#include "common.h"
#include "cmd.h"
#include "parse.h"

int dwindle(Workspace *ws);
int fib(Workspace *ws, int out);
int grid(Workspace *ws);
int mono(Workspace *ws);
int spiral(Workspace *ws);
int tile(Workspace *ws);

#include "config.h"
