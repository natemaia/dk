#pragma once

#include <sys/types.h>

#include <string.h>

size_t strlcat(char *dst, const char *src, size_t siz);
size_t strlcpy(char *dst, const char *src, size_t dsize);
